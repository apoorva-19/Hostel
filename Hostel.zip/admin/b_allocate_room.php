<?php
    session_start();
    if(empty($_SESSION["user"]))
    {
        header("Location:../404.html");
        exit;
    }
    if($_SESSION["user"] != "admin")
    {
        header("Location:../404.html");
        exit;
    }
    require_once("../connect.php");
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["roomNo"]) && isset($_POST["misID"]))
    {
        $jsonArray = array();
        $mis = test_input($_POST["misID"]);
        $room_no = test_input($_POST["roomNo"]);
        $verify = "SELECT `Verify_Warden` FROM `New_Registrations` WHERE `MIS` = ?";
        if(!($verify = $mysqli->prepare($verify)))
        {
            //error_log('Prepare failed for warden verification room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
            $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
            exit;
        }
        if(!($verify->bind_param('s',$mis)))
        {
            //error_log('Bind param failed for warden verification room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
            $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
            exit;
        }
        if(!($verify->execute()))
        {
            //error_log('Execution failed for warden verification room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
            $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
            exit;
        }
        if($result = $verify->get_result())
        {
            $row = $result->fetch_assoc();
            if($row["Verify_Warden"] == 'Y')
            {
                $sql = "UPDATE New_Registrations SET Room_No = ? WHERE MIS = ?";
                if(!($sql = $mysqli->prepare($sql)))
                {
                    //error_log('Prepare failed for allocating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                    $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                    exit;
                }
                if(!($sql->bind_param('ss',$room_no, $mis)))
                {
                    //error_log('Bind param failed for allocating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                    $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                    exit;
                }
                if(!($sql->execute()))
                {
                    //error_log('Execution failed for allocating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                    $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                    exit;
                }
                if(!$result = $sql->get_result() && $mysqli->errno == 0)
                {
                    $sql = "UPDATE B_Room SET Reserved = 'Y' WHERE Room_No = ?";
                    if(!($sql = $mysqli->prepare($sql)))
                    {
                        //error_log('Prepare failed for updating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                        $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                        exit;
                    }
                    if(!($sql->bind_param('s',$room_no)))
                    {
                        //error_log('Bind param failed for updating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                        $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                        exit;
                    }
                    if(!($sql->execute()))
                    {
                        //error_log('Execution failed for upating room in allocate_room.php: ('.$mysqli->errno.') '.$mysqli->error);
                        $jsonArray["result"] = "Request could not be processed. We are trying to fix the error.";
                        exit;
                    }
                    if(!$result = $sql->get_result() && $mysqli->errno == 0)
                    {
                        $jsonArray["result"] = "Room has been alloted successfully!";
                    }
                    else
                    {
                        $jsonArray["result"] = "Room could not be alloted. Please try again";
                    }
                }
                else
                {
                    $jsonArray["result"] = "Room could not be alloted. Please try again";
                } 
            }
            else
            {
                $jsonArray["result"] = "Details not verified. Please verify and try again.";
            }
        }
        else
        {
            $jsonArray["result"] = "Room could not be alloted. Please try again";
        }
        echo json_encode($jsonArray);
    }
?>